package Builder;

public interface IStudentBuilder {
	Student build();
}
