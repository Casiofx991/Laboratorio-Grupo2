/**
 * 
 */
/**
 * @author USER
 *
 */
module PatronesDiseno {
}