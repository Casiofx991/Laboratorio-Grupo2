package Builder2;

public interface IPlantBuilder {
Plant Build();
}
