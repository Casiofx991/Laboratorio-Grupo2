package Builder2;

public interface IBookBuilder {
Book build();
}
